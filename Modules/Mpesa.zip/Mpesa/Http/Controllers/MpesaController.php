<?php

namespace Modules\Mpesa\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Modules\Mpesa\Entities\MpesaSetting;
use Modules\Mpesa\Entities\MpesaTransaction;
use Modules\Mpesa\Services\DarajaService;

class MpesaController extends Controller
{
    /**
     * AJAX endpoint called from the POS "Pay with M-Pesa" modal.
     */
    public function stkPush(Request $request)
    {
        try {
            if (!auth()->user()->can('mpesa.collect_payment')) {
                abort(403, 'Unauthorized action.');
            }

            $request->validate([
                'phone' => 'required|string',
                'amount' => 'required|numeric|min:1',
            ]);

            $business_id = $request->session()->get('user.business_id');

            $service = DarajaService::forBusiness($business_id);

            $phone = $this->normalizePhone($request->input('phone'));

            $callback_url = action('\Modules\Mpesa\Http\Controllers\CallbackController@stkCallback', ['business_id' => $business_id]);

            $account_reference = $request->input('account_reference') ?: ('POS-' . ($request->input('transaction_id') ?: time()));

            $response = $service->stkPush(
                $phone,
                (float) $request->input('amount'),
                $account_reference,
                $callback_url
            );

            if (($response['ResponseCode'] ?? null) !== '0') {
                throw new \Exception($response['ResponseDescription'] ?? 'Failed to initiate M-Pesa payment.');
            }

            $mpesa_transaction = MpesaTransaction::create([
                'business_id'          => $business_id,
                'location_id'          => $request->input('location_id'),
                'transaction_id'       => $request->input('transaction_id'),
                'type'                 => 'stk',
                'status'               => 'pending',
                'phone_number'         => $phone,
                'amount'               => $request->input('amount'),
                'merchant_request_id'  => $response['MerchantRequestID'] ?? null,
                'checkout_request_id'  => $response['CheckoutRequestID'] ?? null,
                'account_reference'    => $account_reference,
            ]);

            $output = [
                'success'              => true,
                'msg'                  => __('mpesa::lang.stk_push_sent'),
                'checkout_request_id'  => $mpesa_transaction->checkout_request_id,
                'mpesa_transaction_id' => $mpesa_transaction->id,
            ];
        } catch (\Exception $e) {
            $output = [
                'success' => false,
                'msg'     => $e->getMessage(),
            ];
        }

        return response()->json($output);
    }

    /**
     * AJAX: poll payment status.
     */
    public function checkStatus(Request $request)
    {
        $business_id = $request->session()->get('user.business_id');
        $checkout_request_id = $request->input('checkout_request_id');

        $mpesa_transaction = MpesaTransaction::forBusiness($business_id)
            ->where('checkout_request_id', $checkout_request_id)
            ->first();

        if (!$mpesa_transaction) {
            return response()->json([
                'success' => false,
                'status'  => 'not_found',
                'msg'     => __('mpesa::lang.transaction_not_found'),
            ]);
        }

        return response()->json([
            'success'              => true,
            'status'               => $mpesa_transaction->status,
            'mpesa_receipt_number' => $mpesa_transaction->mpesa_receipt_number,
            'result_desc'          => $mpesa_transaction->result_desc,
        ]);
    }

    /**
     * AJAX: return recent successful M-Pesa transactions not yet linked to a sale.
     */
    public function recentPayments(Request $request)
    {
        try {
            $business_id = $request->session()->get('user.business_id');

            // Cart total, sent by the POS screen, used to surface the most
            // useful match first - an unlinked M-Pesa payment for exactly
            // (or closest to) what's currently in the cart.
            $cart_total = $request->input('cart_total');
            $cart_total = is_numeric($cart_total) ? (float) $cart_total : null;

            $query = MpesaTransaction::forBusiness($business_id)
                ->where('status', 'success')
                // Show both unused (transaction_id IS NULL) and used (transaction_id IS NOT NULL)
                // so cashiers can see the full recent history. Used ones are flagged below.
                ->whereNotNull('mpesa_receipt_number'); // must have a receipt

            // Cashier can search by phone number (07.., 2547.., or just the
            // last few digits) or by the M-Pesa receipt/transaction code.
            $search = trim((string) $request->input('search'));
            if ($search !== '') {
                $digits = preg_replace('/[^0-9]/', '', $search);

                $query->where(function ($q) use ($search, $digits) {
                    $q->where('mpesa_receipt_number', 'like', "%{$search}%");

                    if ($digits !== '') {
                        $q->orWhere('phone_number', 'like', "%{$digits}%");
                    }
                });
            }

            $transactions = $query
                ->orderBy('created_at', 'desc')
                ->limit(25) // pull a bit more than we show, so exact matches
                            // further back in time still surface after sorting
                ->get(['id', 'mpesa_receipt_number', 'phone_number', 'amount', 'created_at', 'transaction_id', 'invoice_no']);

            if ($cart_total !== null) {
                // Sort so the closest amount match comes first (ties broken by
                // most recent), then trim to the 10 the panel actually shows.
                $transactions = $transactions
                    ->sortBy(function ($tx) use ($cart_total) {
                        return abs((float) $tx->amount - $cart_total);
                    })
                    ->values();
            }

            $transactions = $transactions->take(10)->values();

            // Flag exact matches and used status for the client.
            $transactions = $transactions->map(function ($tx) use ($cart_total) {
                // A transaction is "used" if transaction_id is set and non-zero
                $tx->is_used = !is_null($tx->transaction_id) && $tx->transaction_id != 0;
                $tx->is_exact_match = !$tx->is_used && ($cart_total !== null) && abs((float) $tx->amount - $cart_total) < 0.01;
                return $tx;
            });

            return response()->json([
                'success'      => true,
                'transactions' => $transactions,
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        }
    }

    /**
     * AJAX: link an existing M-Pesa transaction to the current sale and finalize.
     * Called when cashier picks a recent payment from the panel.
     */
    public function linkPayment(Request $request)
    {
        try {
            $request->validate([
                'mpesa_transaction_id' => 'required|integer',
                'cart_total' => 'required|numeric|min:0.01',
            ]);

            $business_id = $request->session()->get('user.business_id');

            $mpesa_transaction = MpesaTransaction::forBusiness($business_id)
                ->where('id', $request->input('mpesa_transaction_id'))
                ->where('status', 'success')
                ->whereNull('transaction_id')
                ->firstOrFail();

            // Authoritative check - this is what actually enforces the rule;
            // the client-side check in pos_button.blade.php is just so the
            // cashier gets instant feedback without a round trip. A payment
            // can only be used if it matches the cart total exactly (to the
            // cent), no split payments / over- or under-payments allowed.
            $cart_total = (float) $request->input('cart_total');
            if (abs((float) $mpesa_transaction->amount - $cart_total) >= 0.01) {
                return response()->json([
                    'success' => false,
                    'msg' => 'This M-Pesa payment (' . number_format($mpesa_transaction->amount, 2) .
                        ') does not match the cart total (' . number_format($cart_total, 2) .
                        '). Pick a payment with the exact amount.',
                ]);
            }

            // Mark as linked so it can't be used again
            // Use -1 as sentinel for "used without a linked sale ID" so is_used check (transaction_id != 0) works correctly
            $mpesa_transaction->transaction_id = $request->input('transaction_id') ?? -1;
            $mpesa_transaction->save();

            return response()->json([
                'success'              => true,
                'mpesa_receipt_number' => $mpesa_transaction->mpesa_receipt_number,
                'amount'               => $mpesa_transaction->amount,
                'phone_number'         => $mpesa_transaction->phone_number,
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        }
    }

    /**
     * List M-Pesa transactions for the business.
     */
    public function transactions(Request $request)
    {
        if (!auth()->user()->can('mpesa.view_transactions')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = $request->session()->get('user.business_id');

        $query = MpesaTransaction::forBusiness($business_id);

        // Simple search box on the Transactions page: matches invoice number,
        // M-Pesa receipt number, or phone number - covers the common ways an
        // admin would want to "look up" a specific M-Pesa payment.
        $search = trim((string) $request->input('search'));
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('invoice_no', 'like', "%{$search}%")
                    ->orWhere('mpesa_receipt_number', 'like', "%{$search}%")
                    ->orWhere('phone_number', 'like', "%{$search}%");
            });
        }

        $transactions = $query->orderBy('id', 'desc')
            ->paginate(25)
            ->appends($request->only('search'));

        return view('mpesa::transactions.index', compact('transactions', 'search'));
    }

    /**
     * Normalize phone to 2547XXXXXXXX format.
     */
    protected function normalizePhone(string $phone): string
    {
        $phone = preg_replace('/[^0-9]/', '', $phone);

        if (str_starts_with($phone, '0')) {
            $phone = '254' . substr($phone, 1);
        } elseif (str_starts_with($phone, '7') || str_starts_with($phone, '1')) {
            $phone = '254' . $phone;
        }

        return $phone;
    }
}